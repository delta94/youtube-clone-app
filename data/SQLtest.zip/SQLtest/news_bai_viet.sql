-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: news
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bai_viet`
--

DROP TABLE IF EXISTS `bai_viet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bai_viet` (
  `ID_BV` varchar(10) NOT NULL,
  `Luot_quan_tam` int(11) NOT NULL,
  `So_luong_luu` int(11) NOT NULL,
  `Trang_thai` int(11) NOT NULL,
  `ID_TT` varchar(10) NOT NULL,
  `Noi_dung` varchar(1000) NOT NULL,
  `Ten_tac_gia` varchar(100) NOT NULL,
  PRIMARY KEY (`ID_BV`,`ID_TT`),
  KEY `ID_TT` (`ID_TT`),
  KEY `hot_post` (`Luot_quan_tam`) USING BTREE,
  CONSTRAINT `bai_viet_ibfk_1` FOREIGN KEY (`ID_TT`) REFERENCES `chu_de` (`ID_TT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bai_viet`
--

LOCK TABLES `bai_viet` WRITE;
/*!40000 ALTER TABLE `bai_viet` DISABLE KEYS */;
INSERT INTO `bai_viet` VALUES ('bv001',2,2,1,'cd006','thoisu/giaothong/oto-khach-tong-xe-container-2-nguoi-chet-14-nguoi-bi-thuong.json','Lai Van Sam'),('bv002',2,2,1,'cd006','thoisu/giaothong/xe-khach-dam-tu-vong-hai-nguoi-di-xe-may-roi-boc-chay.json','Lai Van Sam'),('bv003',1,1,1,'cd006','thoisu/giaothong/tai-xe-oto-bi-nhieu-nguoi-vay-danh-sau-khi-gay-tai-nan-lien-hoan.json','Lai Van Sam'),('bv004',1,1,1,'cd007','thoisu/nongnghiepsach/nong-dan-ninh-thuan-doi-doi-nho-trong-mang-tay.json','Lai Van Sam'),('bv005',0,0,1,'cd007','thoisu/nongnghiepsach/nong-dan-may-mo-trong-3-000-m2-tao-tren-doi-nui-tan-son.json','Lai Van Sam'),('bv006',0,0,1,'cd007','thoisu/nongnghiepsach/quang-binh-bao-ton-giong-toi-tia-dac-san-ba-don.json','Lai Van Sam'),('bv007',1,1,1,'cd008','kinhdoanh/doanhnghiep/ha-i-pho-ng-dua-ca-ng-nuo-c-sau-6-000-ty-dong-va-o-khai-tha-c.json','Vo Thanh'),('bv008',1,1,1,'cd008','kinhdoanh/doanhnghiep/lao-dong-biet-tieng-phap-duoc-san-don.json','Vo Thanh'),('bv009',0,0,1,'cd008','kinhdoanh/doanhnghiep/ong-luon-chong-chay-ac-co-mat-o-nhieu-cong-trinh-hang-sang.json','Vo Thanh'),('bv010',0,0,1,'cd009','kinhdoanh/batdongsan/du-an-nha-o-xa-hoi-day-du-tien-ich-tai-phia-tay-ha-noi.json','Vo Thanh'),('bv011',1,2,1,'cd009','kinhdoanh/batdongsan/gia-dat-dong-nai-long-an-noi-song-theo-con-sot-dat-sai-gon.json','Vo Thanh'),('bv012',2,0,1,'cd009','kinhdoanh/batdongsan/khong-gian-song-xanh-tai-khu-do-thi-lavila-dong-sai-gon.json','Mai Thanh'),('bv013',2,3,1,'cd010','kinhdoanh/chungkhoan/chung-khoan-pho-wall-bi-phat-200-trieu-do-khai-sinh-dich-vu-moi.json','Mai Thanh'),('bv014',0,0,1,'cd010','kinhdoanh/chungkhoan/chung-khoan-viet-nam-giam-manh-nhat-the-gioi-trong-mot-thang.json','Mai Thanh'),('bv015',0,0,1,'cd010','kinhdoanh/chungkhoan/sac-xanh-tro-lai-vn-index-tang-hon-35-diem.json','Mai Thanh'),('bv016',1,1,1,'cd011','giaitri/phim/love-simon-phim-gay-sot-ve-chuyen-dong-tinh-o-hoc-duong.json','Mai Thanh'),('bv017',1,1,1,'cd011','giaitri/phim/nguoi-do-dau-cho-clint-eastwood-martin-scorsese-mat-o-tuoi-81.json','Van An'),('bv018',1,1,1,'cd011','giaitri/phim/nhung-khoanh-khac-xuc-dong-trong-vu-tru-dien-anh-marvel.json','Van An'),('bv019',1,1,1,'cd012','giaitri/thoitrang/lich-lam-nam-tinh-voi-thuong-hieu-4u-fashion-phong-cach-italy.json','Van An'),('bv020',0,1,1,'cd012','giaitri/thoitrang/quan-jeans-ho-het-vong-ba-chay-hang-o-my.json','Van An'),('bv021',2,2,1,'cd012','giaitri/thoitrang/vo-tuong-lai-cua-hoang-tu-anh-mac-vay-cuoi-100-000-bang.json','Van An'),('bv022',0,0,1,'cd013','giaitri/nhac/ba-nhom-nhac-mien-trung-vao-chung-ket-the-band-toan-quoc.json','Di Khanh'),('bv023',3,3,1,'cd013','giaitri/nhac/hoa-minzy-moi-hot-boy-cao-1-86-m-dong-mv.json','Di Khanh'),('bv024',0,0,1,'cd013','giaitri/nhac/luong-nguyet-anh-di-khap-vung-trung-du-tim-canh-quay-mv.json','Di Khanh'),('bv025',0,0,1,'cd014','thethao/bongda/casemiro-la-liga-khong-the-bang-champions-league.json','Di Khanh'),('bv026',0,0,1,'cd014','thethao/bongda/klopp-yeu-cau-salah-cham-dut-tro-an-va.json','Di Khanh'),('bv027',0,0,1,'cd014','thethao/bongda/ronaldo-nguy-co-lo-chung-ket-champions-league.json','Di Khanh'),('bv028',0,0,1,'cd015','thethao/hautruong/ban-gai-ronaldo-khoe-nhan-tri-gia-gan-mot-trieu-dola.json','Di Khanh'),('bv029',0,0,1,'cd015','thethao/hautruong/lebron-james-phat-tai-nho-liverpool-vao-chung-ket-champions-league.json','Nhat Ha'),('bv030',0,0,1,'cd015','thethao/hautruong/the-gioi-bong-da-huong-ve-alex-ferguson.json','Nhat Ha'),('bv031',0,1,1,'cd016','thethao/tennis/dominic-thiem-canh-bao-su-tro-lai-cua-djokovic.json','Nhat Ha'),('bv032',0,0,1,'cd016','thethao/tennis/ly-hoang-nam-vao-tu-ket-don-nam-viet-nam-f1-futures.json','Nhat Ha'),('bv033',0,0,1,'cd016','thethao/tennis/nadal-vo-dich-barcelona-mo-rong-lap-ky-luc-lang-banh-ni.json','Nhat Ha'),('bv034',0,0,1,'cd017','phapluat/hosophaan/don-ly-hon-tren-thi-the-dong-bang-cua-co-gai-trung-quoc.json','Nhat Ha'),('bv035',0,0,1,'cd017','phapluat/hosophaan/dung-kho-nhuc-ke-de-co-khuon-mat-giong-chong-cua-nguoi-tinh.json','Nhat Ha'),('bv036',0,0,1,'cd017','phapluat/hosophaan/tham-tu-giai-ma-duong-di-cua-vien-dan-de-minh-oan-cho-canh-sat-my.json','Nhat Ha');
/*!40000 ALTER TABLE `bai_viet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-13 23:00:37
